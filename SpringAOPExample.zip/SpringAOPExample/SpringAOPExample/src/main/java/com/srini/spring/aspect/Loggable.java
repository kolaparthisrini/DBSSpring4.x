package com.srini.spring.aspect;

public @interface Loggable {

}
