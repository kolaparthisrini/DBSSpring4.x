package org.cap.config;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Profile("development")
@Configuration
//@ComponentScan("org.cap")
public class DevDatabaseConfig implements DatabaseConfig{
	
	DriverManagerDataSource dataSource=new DriverManagerDataSource();

	@Bean
	@Override
	public DataSource getDatSource() {
		System.out.println("Create DataSource - Development");
		///
		//
		//
		return dataSource;
	}

	
	
}
