package org.cap.config;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.getEnvironment().setActiveProfiles("production");
		//context.getEnvironment().setActiveProfiles("production");
		context.register(ProdDatabaseConfig.class);
		
		//context.scan("org.cap");
		context.refresh();
		
		context.close();

	}

}
