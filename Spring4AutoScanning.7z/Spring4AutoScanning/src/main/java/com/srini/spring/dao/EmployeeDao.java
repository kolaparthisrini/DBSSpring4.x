package com.srini.spring.dao;

import com.srini.spring.model.Employee;

public interface EmployeeDao {

	void saveInDatabase(Employee employee);
}
