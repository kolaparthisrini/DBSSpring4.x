package com.srini.spring.service;

import com.srini.spring.model.Employee;

public interface EmployeeService {

	void registerEmployee(Employee employee);
}

