package com.cg.demo;

public abstract class AbstractLookupDemoBean implements DemoBean {

	@Override
	public void doSomeOperation() {
		// TODO Auto-generated method stub
		getMyHelper().doSomethingHelpful();
	}


	abstract public MyHelper getMyHelper();

}
