package com.cg.demo;

public class StandardLookupBean implements DemoBean {
	private MyHelper myHelper;
	@Override
	public void doSomeOperation() {
		// TODO Auto-generated method stub
			myHelper.doSomethingHelpful();
	}

	@Override
	public MyHelper getMyHelper() {
		// TODO Auto-generated method stub
		return myHelper;
	}

	public void setMyHelper(MyHelper myHelper){
		this.myHelper = myHelper;
	}
}
