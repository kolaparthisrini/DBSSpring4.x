package com.cg.demo;

public class MyHelper {
	public void doSomethingHelpful(){
		
		// do something! 
	}
}
