package com.cg.demo;

public class Bar {

}
